
pub mod fruit_and_vegetable_shop {
    pub mod fruit_corner{
        pub fn types_of_oranges() {

        }
    }
}