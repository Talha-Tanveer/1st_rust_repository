pub fn counter(start: i32, end: i32) {
    for index in start..end{
        println!("Counting: {}", index);
    }
}